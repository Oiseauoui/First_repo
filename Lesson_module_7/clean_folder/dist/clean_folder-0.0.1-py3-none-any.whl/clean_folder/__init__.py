from clean_folder.clean import main
from clean_folder.files_generator import file_generator

__all__ = ['main', 'file_generator']